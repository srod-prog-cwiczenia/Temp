package helper;

public enum Kolor {
  BIALY, CZARNY;
}
